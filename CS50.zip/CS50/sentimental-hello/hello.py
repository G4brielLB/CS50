# Asks the name of the user
name = input("What is your name? ")
# Prints hello, name
print(f"hello, {name}")